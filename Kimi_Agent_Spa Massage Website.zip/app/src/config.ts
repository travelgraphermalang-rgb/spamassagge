// Site configuration
// Konfigurasi website Spa Massage & Wellness

export interface SiteConfig {
  language: string;
  title: string;
  description: string;
}

export const siteConfig: SiteConfig = {
  language: "id",
  title: "Serenity Spa - Wellness & Massage Center",
  description: "Serenity Spa menawarkan pengalaman relaksasi terbaik dengan berbagai treatment massage, body scrub, dan perawatan kecantikan oleh terapis profesional.",
};

// Navigation configuration
export interface NavLink {
  label: string;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  links: NavLink[];
  contactLabel: string;
  contactHref: string;
}

export const navigationConfig: NavigationConfig = {
  logo: "Serenity Spa",
  links: [
    { label: "Beranda", href: "#hero" },
    { label: "Tentang", href: "#about" },
    { label: "Layanan", href: "#services" },
    { label: "Galeri", href: "#portfolio" },
    { label: "Testimoni", href: "#testimonials" },
  ],
  contactLabel: "Reservasi",
  contactHref: "#cta",
};

// Hero section configuration
export interface HeroConfig {
  name: string;
  roles: string[];
  backgroundImage: string;
}

export const heroConfig: HeroConfig = {
  name: "Serenity Spa",
  roles: [
    "Massage Therapy",
    "Body Treatment",
    "Facial Care",
    "Wellness Center",
  ],
  backgroundImage: "/images/hero-bg.jpg",
};

// About section configuration
export interface AboutStat {
  value: string;
  label: string;
}

export interface AboutImage {
  src: string;
  alt: string;
}

export interface AboutConfig {
  label: string;
  description: string;
  experienceValue: string;
  experienceLabel: string;
  stats: AboutStat[];
  images: AboutImage[];
}

export const aboutConfig: AboutConfig = {
  label: "Tentang Kami",
  description: "Serenity Spa adalah pusat wellness yang didedikasikan untuk memberikan pengalaman relaksasi dan peremajaan terbaik. Dengan terapis berpengalaman dan produk alami berkualitas tinggi, kami membantu Anda menemukan keseimbangan dan ketenangan dalam kesibukan sehari-hari.",
  experienceValue: "10+",
  experienceLabel: "Tahun\nPengalaman",
  stats: [
    { value: "2", label: "Treatment" },
    { value: "15K+", label: "Pelanggan Puas" },
    { value: "20+", label: "Terapis Profesional" },
  ],
  images: [
    { src: "/images/about-1.jpg", alt: "Ruang Treatment Serenity Spa" },
    { src: "/images/about-2.jpg", alt: "Aromatherapy Massage" },
    { src: "/images/about-3.jpg", alt: "Kolam Relaksasi" },
    { src: "/images/about-4.jpg", alt: "Lounge Area" },
  ],
};

// Services section configuration
export interface ServiceItem {
  iconName: string;
  title: string;
  description: string;
  image: string;
}

export interface ServicesConfig {
  label: string;
  heading: string;
  services: ServiceItem[];
}

export const servicesConfig: ServicesConfig = {
  label: "Layanan Kami",
  heading: "Treatment Traditional Massage",
  services: [
    {
      iconName: "Clock",
      title: "Traditional Massage 1,5 Jam",
      description: "Pijatan tradisional penuh selama 90 menit untuk relaksasi menyeluruh. Melepaskan ketegangan otot, meningkatkan sirkulasi darah, dan memulihkan energi tubuh.",
      image: "/images/service-1.jpg",
    },
    {
      iconName: "Timer",
      title: "Traditional Massage 2 Jam",
      description: "Pengalaman spa premium selama 120 menit dengan pijatan mendalam. Treatment lengkap untuk relaksasi maksimal dan kesejahteraan tubuh yang optimal.",
      image: "/images/service-2.jpg",
    },
  ],
};

// Portfolio section configuration
export interface ProjectItem {
  title: string;
  category: string;
  year: string;
  image: string;
  featured?: boolean;
}

export interface PortfolioCTA {
  label: string;
  heading: string;
  linkText: string;
  linkHref: string;
}

export interface PortfolioConfig {
  label: string;
  heading: string;
  description: string;
  projects: ProjectItem[];
  cta: PortfolioCTA;
  viewAllLabel: string;
}

export const portfolioConfig: PortfolioConfig = {
  label: "Galeri",
  heading: "Momen Relaksasi",
  description: "Lihat pengalaman istimewa yang telah kami ciptakan untuk para tamu kami. Setiap treatment dirancang untuk memberikan ketenangan dan kesejahteraan.",
  projects: [
    {
      title: "Couple Spa Package",
      category: "Romantic Experience",
      year: "2024",
      image: "/images/portfolio-1.jpg",
      featured: true,
    },
    {
      title: "Balinese Massage",
      category: "Traditional Therapy",
      year: "2024",
      image: "/images/portfolio-2.jpg",
    },
    {
      title: "Thai Herbal Compress",
      category: "Healing Treatment",
      year: "2023",
      image: "/images/portfolio-3.jpg",
    },
    {
      title: "Body Scrub Treatment",
      category: "Body Care",
      year: "2023",
      image: "/images/portfolio-4.jpg",
    },
    {
      title: "Meditation & Yoga",
      category: "Wellness Program",
      year: "2023",
      image: "/images/portfolio-5.jpg",
    },
  ],
  cta: {
    label: "Ingin Relaksasi?",
    heading: "Dapatkan Pengalaman Spa Terbaik",
    linkText: "Pesan Sekarang",
    linkHref: "#cta",
  },
  viewAllLabel: "Lihat Semua Galeri",
};

// Testimonials section configuration
export interface TestimonialItem {
  quote: string;
  author: string;
  role: string;
  company: string;
  image: string;
  rating: number;
}

export interface TestimonialsConfig {
  label: string;
  heading: string;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  label: "Testimoni",
  heading: "Apa Kata Pelanggan Kami",
  testimonials: [
    {
      quote: "Pengalaman spa terbaik yang pernah saya rasakan! Terapisnya sangat profesional dan ruangannya sangat nyaman. Swedish massage-nya benar-benar melepas semua ketegangan.",
      author: "Dewi Santoso",
      role: "Business Owner",
      company: "Jakarta",
      image: "/images/testimonial-1.jpg",
      rating: 5,
    },
    {
      quote: "Saya menjadi langganan setia Serenity Spa selama 3 tahun. Kualitas treatment dan pelayanannya selalu konsisten. Hot stone therapy adalah favorit saya!",
      author: "Linda Wijaya",
      role: "Marketing Director",
      company: "Surabaya",
      image: "/images/testimonial-2.jpg",
      rating: 5,
    },
    {
      quote: "Facial treatment di sini luar biasa! Kulit saya terasa lebih segar dan glowing. Produk yang digunakan juga berkualitas dan wangi aromatherapinya sangat menenangkan.",
      author: "Maya Anggraini",
      role: "Content Creator",
      company: "Bandung",
      image: "/images/testimonial-3.jpg",
      rating: 5,
    },
  ],
};

// CTA section configuration
export interface CTAConfig {
  tags: string[];
  heading: string;
  description: string;
  buttonText: string;
  buttonHref: string;
  email: string;
  backgroundImage: string;
}

export const ctaConfig: CTAConfig = {
  tags: ["Traditional Massage 1,5 Jam", "Traditional Massage 2 Jam"],
  heading: "Mulai Perjalanan Wellness Anda",
  description: "Hubungi kami untuk reservasi dan dapatkan konsultasi gratis tentang treatment yang paling sesuai untuk kebutuhan Anda.",
  buttonText: "Reservasi Sekarang",
  buttonHref: "tel:+6281234567890",
  email: "hello@serenityspa.id",
  backgroundImage: "/images/cta-bg.jpg",
};

// Footer section configuration
export interface FooterLinkColumn {
  title: string;
  links: { label: string; href: string }[];
}

export interface SocialLink {
  iconName: string;
  href: string;
  label: string;
}

export interface FooterConfig {
  logo: string;
  description: string;
  columns: FooterLinkColumn[];
  socialLinks: SocialLink[];
  newsletterHeading: string;
  newsletterDescription: string;
  newsletterButtonText: string;
  newsletterPlaceholder: string;
  copyright: string;
  credit: string;
}

export const footerConfig: FooterConfig = {
  logo: "Serenity Spa",
  description: "Pusat wellness dan spa terbaik untuk relaksasi, peremajaan, dan kesejahteraan tubuh serta pikiran Anda.",
  columns: [
    {
      title: "Layanan",
      links: [
        { label: "Swedish Massage", href: "#services" },
        { label: "Hot Stone Therapy", href: "#services" },
        { label: "Aromatherapy", href: "#services" },
        { label: "Facial Treatment", href: "#services" },
      ],
    },
    {
      title: "Tentang",
      links: [
        { label: "Tentang Kami", href: "#about" },
        { label: "Galeri", href: "#portfolio" },
        { label: "Karir", href: "#" },
        { label: "Blog", href: "#" },
      ],
    },
    {
      title: "Kontak",
      links: [
        { label: "hello@serenityspa.id", href: "mailto:hello@serenityspa.id" },
        { label: "+62 812 3456 7890", href: "tel:+6281234567890" },
        { label: "Jakarta, Indonesia", href: "#" },
      ],
    },
  ],
  socialLinks: [
    { iconName: "Instagram", href: "https://instagram.com", label: "Instagram" },
    { iconName: "Facebook", href: "https://facebook.com", label: "Facebook" },
    { iconName: "Youtube", href: "https://youtube.com", label: "YouTube" },
    { iconName: "Twitter", href: "https://twitter.com", label: "Twitter" },
  ],
  newsletterHeading: "Berlangganan Newsletter",
  newsletterDescription: "Dapatkan promo eksklusif dan tips wellness langsung ke email Anda.",
  newsletterButtonText: "Berlangganan",
  newsletterPlaceholder: "Masukkan email Anda",
  copyright: "© 2024 Serenity Spa. Hak Cipta Dilindungi.",
  credit: "Dibuat dengan ❤️ untuk kesejahteraan Anda",
};
